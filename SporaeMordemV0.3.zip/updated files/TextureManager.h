#pragma once
#include "basic_includes.h"
#include "Engine.h"
class TextureManager
{
private:
	TextureManager();
	vector<SDL_Texture*> textures;
public:
	~TextureManager();
	static TextureManager& getInstance();
	int addTexture(string texture); //loads the texture to the vector and returns the id the texture is stored at
	SDL_Texture* getTexture(int TextureID); //returns the texture stored at a specific id
};

