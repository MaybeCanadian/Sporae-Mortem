#include "TextureManager.h"
#include "basic_includes.h"


TextureManager::TextureManager()
{
}

TextureManager::~TextureManager()
{
}

TextureManager & TextureManager::getInstance()
{
	static TextureManager instance;
	return instance;
}

SDL_Texture * TextureManager::getTexture(int TextureID)
{
	return textures[TextureID];
}

int TextureManager::addTexture(string texture)
{
	SDL_Texture *textureBuffer;
	const char* charBuffer = texture.c_str();
	textureBuffer =  IMG_LoadTexture(Engine::getInstance().getRenderer(), charBuffer);
	textures.push_back(textureBuffer);
	return ((int)textures.size() - 1);
}

