#pragma once
#include "basic_includes.h"
#include "Engine.h"
#include "Player.h"
class sky
{
private:
	SDL_Rect m_dst;
	int speed;
	void scroll(string);
public:
	SDL_Rect getRect();
	~sky();
	sky();
	void update();
	sky& getInstance();
};

