#pragma once
#include <SDL.h>
#include <SDL_image.h>
#include <SDL_mixer.h>
#include <SDL_ttf.h>
#include <iostream>
#include <string>
#define WIDTH 1024
#define HEIGHT 768
#define FPS 60
using namespace std;