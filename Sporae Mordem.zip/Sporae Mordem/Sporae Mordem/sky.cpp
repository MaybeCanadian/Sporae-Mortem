#include "sky.h"



SDL_Rect sky::getRect()
{
	return m_dst;
}

sky::sky()
{
	m_dst.x = WIDTH / 2;
	m_dst.y = HEIGHT / 2;
	m_dst.h = 500;
	m_dst.w = 500;
	speed = 5;
}

void sky::update()
{
}


sky::~sky()
{
}



void sky::scroll(string input)
{
	if (input == "up")
	{
		if (m_dst.y < 1000)
			m_dst.y -= speed;
	}
	else if (input == "down")
	{
		if (m_dst.y > 0)
			m_dst.y += speed;
	}
	else if (input == "left")
	{
		if (m_dst.x > 0)
			m_dst.x -= speed;
	}
	else if (input == "right")
	{
		if (m_dst.x < 1500)
			m_dst.x += speed;
	}
	else
		cout << "error" << endl;
}
