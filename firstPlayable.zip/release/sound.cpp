#include "sound.h"

sound::sound(int x, int y, double radius, int duration)
{
	this->x = x;
	this->y = y;
	this->radius = radius;
	current_duration = 0;
	max_duration = duration;
}
sound::~sound()
{
}

int const sound::getSoundX()
{
	return x;
}

int const sound::getSoundY()
{
	return y;
}

double const sound::getSoundRadius()
{
	return radius;
}

int const sound::getSoundMaxDur()
{
	return max_duration;
}

int const sound::getSoundCurDur()
{
	return current_duration;
}
