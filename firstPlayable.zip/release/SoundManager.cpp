#include "SoundManager.h"



SoundManager::SoundManager()
{
	cout << "Sound manager constucted" << endl;
}


SoundManager & SoundManager::getInstance()
{
	static SoundManager insatnce;
	return insatnce;
}

void SoundManager::soundCreate(int x, int y, int radius, int duration)
{
	sounds.push_back(new sound(x, y, radius, duration));
}

void SoundManager::soundUpdate()
{
	if (!sounds.empty())
	{
		for (int i = 0; i < (int)sounds.size(); i++)
		{
			//unimplemented at this time
		}
	}
}

SoundManager::~SoundManager()
{
}
