#pragma once
#include"basic_includes.h"
class sound
{
private:
	int x, y;
	double radius;
	int current_duration, max_duration; //in frames

public:
	sound(int x, int y, double radius, int duration);
	~sound();
	int const getSoundX();
	int const getSoundY();
	double const getSoundRadius();
	int const getSoundMaxDur();
	int const getSoundCurDur();
};

