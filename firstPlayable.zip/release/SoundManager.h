#pragma once
#include "basic_includes.h"
#include "sound.h"

class sound;
class SoundManager
{
private:
	SoundManager();
	vector<sound*> sounds;
public:
	static SoundManager& getInstance();
	void soundCreate(int x, int y, int radius, int duration);
	void soundUpdate();
	~SoundManager();
};

