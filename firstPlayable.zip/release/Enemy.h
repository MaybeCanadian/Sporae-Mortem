#pragma once
#include "basic_includes.h"
class Enemy
{
private:
	SDL_Rect m_dst;
	double rotation;
	vector<SDL_Rect> wallVec;
public:
	Enemy(vector<SDL_Rect>);
	~Enemy();
	void update();
	void render();
	SDL_Rect getRect();
	double getRotation();
	void turnRight();
	bool check(char);
	void move();
	void turnLeft();
};

