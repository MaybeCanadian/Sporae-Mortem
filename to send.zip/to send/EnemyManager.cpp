#include "EnemyManager.h"



EnemyManager::EnemyManager()
{
}

bool EnemyManager::initManager()
{
	//nothing to init yet
	std::cout << "enemyManager init.\n";
	return true;
}

void EnemyManager::clean()
{
	//nothing to clean yet
	std::cout << "enemyManager clean.\n";
}


EnemyManager::~EnemyManager()
{
}
